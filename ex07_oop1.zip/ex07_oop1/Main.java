package sungil.ex07_oop1;

public class Main {
    public static void main(String[] args) {
        Iphone 아이폰13 = new Iphone();
        아이폰13.set메모리(16);
        아이폰13.set모델버전("13");
        아이폰13.set색상("SpaceGray");
        아이폰13.set스크린크기(12344);
        아이폰13.set카메라화소수(13000000);

        System.out.println(아이폰13.get메모리());
        System.out.println(아이폰13.get모델버전());
        System.out.println(아이폰13.get색상());
        System.out.println(아이폰13.get스크린크기());
        System.out.println(아이폰13.get카메라화소수());

        아이폰13.음악듣기("정이라고하자");


   }


}
